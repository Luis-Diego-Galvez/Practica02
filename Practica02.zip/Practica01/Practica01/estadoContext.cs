using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;
using Practica01.Models;

namespace  Practica01
{
    public class estadoContext : DbContext
    {
        public estadoContext(DbContextOptions<estadoContext> options) : base(options)
        {            
        }

        public DbSet<equipos> estado {get; set;}
    }
}