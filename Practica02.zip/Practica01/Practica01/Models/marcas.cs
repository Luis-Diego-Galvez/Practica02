using System;
using System.ComponentModel.DataAnnotations;
namespace Practica01.Models
{
    public class marcas{
         [Key]
        public int id_marca { get; set; }
        public string nombre { get; set; }
        
    }
}