using System;
using System.ComponentModel.DataAnnotations;
namespace Practica01.Models
{
    public class tipo{
         [Key]
        public int tipo_equipo_id { get; set; }
        
        
    }
}