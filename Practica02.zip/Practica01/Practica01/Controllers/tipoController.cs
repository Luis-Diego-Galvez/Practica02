using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Practica01.Models;
using Microsoft.EntityFrameworkCore;


namespace Practica01.Controllers
{
    [ApiController] 
    public class tipoController : ControllerBase
    {
        private readonly tipoContext _contexto;

        public tipoController(tipoContext miContexto) {
            this._contexto = miContexto;
        }

        [HttpGet]
        [Route("api/equipos")]
        public IActionResult Get(){
            var tiposList = _contexto.tipo;
            if(tiposList.Count>0){
                return Ok(tiposList);
            }
            return NotFound();            
        } 

    }