using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Practica01.Models;
using Microsoft.EntityFrameworkCore;

namespace Practica01.Controllers
{
    [ApiController] 
    public class estadoController : ControllerBase
    {
        private readonly estadoContext _contexto;

        public estadoController(estadoContext miContexto) {
            this._contexto = miContexto;
        }

        [HttpGet]
        [Route("api/equipos")]
        public IActionResult Get()
        {
            IEnumerable<equipos> estadosList = from e in _contexto.estado select e;
            if (estadosList.Count() > 0)
            {
                return Ok(estadosList);
            }
            return NotFound();
        }
        /// <param name="buscarNombre"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/equipo/buscarnombre/{buscarNombre}")]
        public IActionResult obtenerNombre(string buscarNombre)
        {
            IEnumerable<equipos> estadoPorNombre = from e in _contexto.estado
                                                   where e.nombre.Contains(buscarNombre)
                                                   select e;
            if (estadoPorNombre.Count() > 0)
            {
                return Ok(estadoPorNombre);
            }

            return NotFound();
        }


        [HttpPost]
        [Route("api/equipos")]
        public IActionResult guardarEquipo([FromBody] equipos estadoNuevo)
        {
            try
            {
                IEnumerable<equipos> estadoExiste = from e in _contexto.equipos
                                                    where e.nombre == estadoNuevo.nombre

                                                    select e;
                if (estadoExiste.Count() == 0)
                {
                    _contexto.estado.Add(estadoNuevo);
                    _contexto.SaveChanges();
                    return Ok(estadoNuevo);
                }
                return Ok(estadoExiste);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("api/equipos")]
        public IActionResult updateEquipo([FromBody] equipos estadoAModificar)
        {
            equipos estadoExiste = (from e in _contexto.estado
                                    where e.id_estados == estadoAModificar.id_estados
                                    select e).FirstOrDefault();
            if (estadoExiste is null)
            {
                return NotFound();
            }

            estadoExiste.nombre = estadoAModificar.nombre;
            estadoExiste.descripcion = estadoAModificar.descripcion;
            estadoExiste.modelo = estadoAModificar.modelo;

            _contexto.Entry(estadoExiste).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(estadoExiste);

        }

    }
}