using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;
using Practica01.Models;

namespace  Practica01
{
    public class tipoContext : DbContext
    {
        public tipoContext(DbContextOptions<tipoContext> options) : base(options)
        {            
        }

        public DbSet<equipos> tipo {get; set;}
    }
}